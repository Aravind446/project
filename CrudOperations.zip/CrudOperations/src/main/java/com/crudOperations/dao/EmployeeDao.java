package com.crudOperations.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import com.crudOperations.entity.Employee;

@Component
public class EmployeeDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	//Create
	
	@Transactional
	public void create(Employee employee) {
	
	this.hibernateTemplate.save(employee);

	}
	
	//get
	public List<Employee> getEmployees(){
		List<Employee> employees = this.hibernateTemplate.loadAll(Employee.class);
		
		return employees;	
	}

	//delete
	@Transactional
	public void delete(int id) {
		
		Employee emp = this.hibernateTemplate.load(Employee.class, id);
		this.hibernateTemplate.delete(emp);	
	}
	//get single emp
	
	public Employee getEmployee(int id) {
		
		return this.hibernateTemplate.load(Employee.class, id);
		
		
	}

	public void deleteEmployee(Object employeeId) {
		// TODO Auto-generated method stub
		
	}
}
