package com.crudOperations.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import com.crudOperations.dao.EmployeeDao;
import com.crudOperations.entity.Employee;

@Controller
public class MainController {

	private EmployeeDao employeedao;
	
	@Autowired
	@RequestMapping("/")
	public String home(Model p) {
		
		List<Employee>employee =employeedao.getEmployees();
	 p.addAttribute("employee", employee);
		return "index";
	}
	
	@RequestMapping("/add-Employee")
	public String addEmployee(Model m) {
		m.addAttribute("title","Add Employee");
		
		return "add_employee_form";
	} 
	@RequestMapping(value="/handle-employee",method = RequestMethod.POST)
	public RedirectView handleProduct(@ModelAttribute Employee employee, HttpServletRequest request) {
		System.out.println(employee);
		employeedao.create(employee);
		
		RedirectView redirectView = new RedirectView();
		redirectView .setUrl (request.getContextPath() + "/");
		return redirectView;
	}
	@RequestMapping("/delete/${employeeId}")
	public RedirectView deleteEmployee(@PathVariable("employeeid") int productId,HttpServletRequest request) {
		this.employeedao.deleteEmployee(employeedao);

		RedirectView redirectView = new RedirectView();
		redirectView .setUrl (request.getContextPath() + "/");
		return redirectView;
	}
	@RequestMapping("/update/{employeeid}")
	public String update(@PathVariable("employeeid") int eid, Model model) {
		Employee employee = this.employeedao.getEmployee(eid);
		model.addAttribute("employee", employee);
		return "update_form";
	}
}
